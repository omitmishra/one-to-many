package com.test.jpa.dto;


import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.test.jpa.entity.Product;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class ProductDTO {
    private Long id;
    private String productName;
    private int qty;
    private int price;

    private Long customerId;

    public ProductDTO(Product prd) {
        this.id=prd.getPid();
        this.productName=prd.getProductName();
        this.qty=prd.getQty();
        this.price=prd.getPrice();
        this.customerId=prd.getCustomerId();
    }
}
