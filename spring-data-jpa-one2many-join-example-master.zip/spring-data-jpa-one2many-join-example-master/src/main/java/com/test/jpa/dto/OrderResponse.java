package com.test.jpa.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.test.jpa.entity.Product;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
@JsonIgnoreProperties(ignoreUnknown = true)
public class OrderResponse {

    private String name;
    private String productName;

    private  int qty;

    public OrderResponse(String name, String productName, int qty) {
        this.name = name;
        this.productName = productName;
        this.qty = qty;
    }

    private Product prd;

    public OrderResponse(String name, Product prd) {
        this.name = name;
        this.prd = prd;
    }

    public OrderResponse(String name, String productName) {
        this.name = name;
        this.productName = productName;
    }

    private int price;
}
