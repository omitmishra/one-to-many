package com.test.jpa.entity;

import com.fasterxml.jackson.annotation.JsonManagedReference;
import com.test.jpa.dto.CustomerDTO;
import com.test.jpa.dto.ProductDTO;
import lombok.*;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.List;
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Getter
@Setter
public class Customer extends Base {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String name;
    private String email;
    private String gender;
    @OneToMany(mappedBy="customer",cascade = CascadeType.ALL)
    @JsonManagedReference
    private List<Product> products;

    public Customer(CustomerDTO custDTO) {

        super();
        this.id= custDTO.getId();
        this.name= custDTO.getName();
        this.email= custDTO.getEmail();
        this.gender=custDTO.getGender();
        if(this.products==null) {
            this.products = new ArrayList<>();
        }
        for(ProductDTO prd:custDTO.getProducts()){
            this.products.add(new Product(prd));
        }

    }
}
