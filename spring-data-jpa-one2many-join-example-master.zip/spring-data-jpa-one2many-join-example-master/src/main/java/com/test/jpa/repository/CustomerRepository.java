package com.test.jpa.repository;

import com.test.jpa.dto.OrderResponse;
import com.test.jpa.entity.Customer;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface CustomerRepository extends JpaRepository<Customer,Long> {

   @Query("SELECT new com.test.jpa.dto.OrderResponse(c.name, p.productName,p.qty) FROM Customer c JOIN c.products p ")
    public List<OrderResponse> getJoinInformation();

    @Query("SELECT c FROM Customer c where c.id=:id ")
    public Customer getCustomerById(@Param("id") Long id);




}
