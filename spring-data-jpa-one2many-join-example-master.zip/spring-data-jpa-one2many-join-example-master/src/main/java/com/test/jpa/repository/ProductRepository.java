package com.test.jpa.repository;

import com.test.jpa.entity.Customer;
import com.test.jpa.entity.Product;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface ProductRepository extends JpaRepository<Product,Long> {


    @Query("SELECT p FROM Product p where p.customerId=:id ")
    public List<Product> getProductById(@Param("id") Long id);
}
