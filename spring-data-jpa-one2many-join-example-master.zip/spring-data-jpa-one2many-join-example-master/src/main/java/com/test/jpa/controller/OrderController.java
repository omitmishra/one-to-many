package com.test.jpa.controller;

import com.test.jpa.dto.OrderRequest;
import com.test.jpa.dto.OrderResponse;
import com.test.jpa.dto.ProductDTO;
import com.test.jpa.entity.Customer;
import com.test.jpa.entity.Product;
import com.test.jpa.repository.CustomerRepository;
import com.test.jpa.repository.ProductRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@RestController
public class OrderController {
    @Autowired
    private CustomerRepository customerRepository;
    @Autowired
    private ProductRepository productRepository;

    @PostMapping ("/placeOrder")
    @Transactional
    public Customer placeOrder(@RequestBody OrderRequest request){
        Customer cust=null;
        List<Product>pall=new ArrayList<>();

        if(request.getCustomer().getId()==null){
           cust=new Customer(request.getCustomer());
           for(ProductDTO prd:request.getCustomer().getProducts()) {
               Product pre=new Product(prd);
               pall.add(pre);
               pre.setCustomer(cust);

           }
            cust.setProducts(pall);

        }else {
            cust= customerRepository.getCustomerById(request.getCustomer().getId());
            cust.setEmail(request.getCustomer().getEmail());
            cust.setGender(request.getCustomer().getGender());
            cust.setName(request.getCustomer().getName());

            List<Product> prds=productRepository.getProductById(request.getCustomer().getId());
            Map<Long,Product> productMap=new HashMap<>();
            for(Product p:prds){
                productMap.put(p.getPid(),p);
            }
            List<ProductDTO> prdDto=request.getCustomer().getProducts();
            for(ProductDTO prdto:prdDto){
                Product ps=null;
                if(prdto.getId()!=null)
                {
                    ps=productMap.get(prdto.getId());
                    ps.setPrice(prdto.getPrice());
                    ps.setProductName(prdto.getProductName());
                    ps.setQty(prdto.getQty());

                }else

                {
                    ps = new Product(prdto);
                    ps.setCustomer(cust);
                }
                pall.add(ps);
            }
            cust.setProducts(pall);
        }
        cust=customerRepository.save(cust);
        return cust;
    }

    @GetMapping("/findAllOrders")
    public List<Customer> findAllOrders(){
        return customerRepository.findAll();
    }

    @GetMapping("/getInfo")
    public List<OrderResponse> getJoinInformation(){
        return customerRepository.getJoinInformation();
    }
}
