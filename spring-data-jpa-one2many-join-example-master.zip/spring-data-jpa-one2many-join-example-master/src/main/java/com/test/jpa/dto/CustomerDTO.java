package com.test.jpa.dto;


import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.test.jpa.entity.Customer;
import com.test.jpa.entity.Product;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.ArrayList;
import java.util.List;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties
public class CustomerDTO {
    private  Long id;
    private String name;
    private String email;
    private String gender;
    List<ProductDTO> products;

    public CustomerDTO(Customer cust) {
        this.id=cust.getId();
        this.name=cust.getName();
        this.gender=cust.getGender();
        if(cust.getProducts()!=null){
            this.products=new ArrayList<>();
            for(Product prd:cust.getProducts()){
                this.products.add(new ProductDTO(prd));

            }
        }
    }
}
