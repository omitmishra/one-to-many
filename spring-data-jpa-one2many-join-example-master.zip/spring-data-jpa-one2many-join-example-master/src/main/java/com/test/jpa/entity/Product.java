package com.test.jpa.entity;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.test.jpa.dto.ProductDTO;
import lombok.*;

import javax.persistence.*;

@AllArgsConstructor
@NoArgsConstructor
@Entity
@Getter
@Setter
public class Product extends Base {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long pid;

    private String productName;
    private int qty;
    private int price;

    @ManyToOne
    @JoinColumn(name="customer_id", nullable=false)
    @JsonBackReference
    private Customer customer;

    @Column(name="customer_id",updatable = false,insertable = false,nullable = false)
    private Long customerId ;

    public Product(ProductDTO prd) {
        super();
        this.productName=prd.getProductName();
        this.qty=prd.getQty();
        this.price=prd.getPrice();
        this.customerId=prd.getId();
    }
}
